/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/06/2023
 * File Name: Observable.java
 * Description: Observable interface.
 */
package edu.bu.met.cs665.services;

import edu.bu.met.cs665.models.Observer;

public interface Observable {
	
	public void registerObserver(Observer observer);
	public void unregisterObserver(Observer observer);
//	public void notifyObservers(DeliveryRequest deliveryRequest);
	void notifyObservers();
	
}
