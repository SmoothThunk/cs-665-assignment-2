/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/06/2023
 * File Name: Van.java
 * Description: Van class inherited from Vehicle.
 */
package edu.bu.met.cs665.models;

public class Van extends Vehicle {

	public Van() {
		super("Van");
	}
	
}
