/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/06/2023
 * File Name: Taxi.java
 * Description: Taxi class inherited from Vehicle.
 */
package edu.bu.met.cs665.models;

public class Taxi extends Vehicle {

	public Taxi() {
		super("Taxi");
	}

}
