/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/06/2023
 * File Name: Observer.java
 * Description: Observer interface.
 */
package edu.bu.met.cs665.models;

public interface Observer {

	public void update(DeliveryRequest deliveryRequest);
	
}
